<?php
class Employee
{
    private $first_name;
    private $last_name;
    private $age;

    public function __construct($first_name, $last_name, $age)
    {
        $this->first_name = $first_name;
        $this->last_name = $last_name;
        $this->age = $age;
    }

    public function getFirstName()
    {
        return $this->first_name;
    }

    public function getLastName()
    {
        return $this->last_name;
    }

    public function getAge()
    {
        return $this->age;
    }
}

$objEmployeeOne = new Employee('Bob', 'Smith', 30);
// Menggunakan \n untuk baris baru
echo $objEmployeeOne->getFirstName() ;
echo $objEmployeeOne->getLastName() . "\n" ;
echo $objEmployeeOne->getAge() . "\n\n"; 

$objEmployeeTwo = new Employee('John', 'Smith', 34);
echo $objEmployeeTwo->getFirstName();
echo $objEmployeeTwo->getLastName() . "\n" ;
echo $objEmployeeTwo->getAge() . "\n";
?>