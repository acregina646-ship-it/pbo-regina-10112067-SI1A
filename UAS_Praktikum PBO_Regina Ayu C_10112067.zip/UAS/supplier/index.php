<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Supplier</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
    <div class="judul">		
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Data Supplier</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Data Supplier</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <?php
        if(isset($_GET['pesan'])){
            if($_GET['pesan'] == "input") echo "<div style='background:#d4edda; color:#155724; padding:10px; margin-bottom:10px;'>Data berhasil di input.</div>";
            if($_GET['pesan'] == "update") echo "<div style='background:#d4edda; color:#155724; padding:10px; margin-bottom:10px;'>Data berhasil di update.</div>";
            if($_GET['pesan'] == "hapus") echo "<div style='background:#d4edda; color:#155724; padding:10px; margin-bottom:10px;'>Data berhasil di hapus.</div>";
        }
        ?>
        
        <a class="tombol" href="input.php">+ Tambah Supplier Baru</a>
        
        <h3>Data Supplier</h3>
        
        <table border="1" class="table">
            <tr>
                <th>No</th>
                <th>ID Supplier</th>
                <th>Nama Supplier</th>
                <th>Alamat</th>
                <th>Telepon</th>
                <th>Email</th>
                <th>Opsi</th>
            </tr>
            <?php
            $query = mysqli_query($koneksi, "SELECT * FROM tb_supplier");
            $nomor = 1;
            while($data = mysqli_fetch_array($query)){
            ?>
            <tr>
                <td><?php echo $nomor++; ?></td>
                <td><?php echo $data['id_supplier']; ?></td>
                <td><?php echo $data['nama_supplier']; ?></td>
                <td><?php echo $data['alamat_supplier']; ?></td>
                <td><?php echo $data['telepon_supplier']; ?></td>
                <td><?php echo $data['email_supplier']; ?></td>
                <td>
                    <a class="edit" href="edit.php?id=<?php echo $data['id_supplier']; ?>">Edit</a> |
                    <a class="hapus" href="hapus.php?id=<?php echo $data['id_supplier']; ?>" onclick="return confirm('Yakin hapus?')">Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>