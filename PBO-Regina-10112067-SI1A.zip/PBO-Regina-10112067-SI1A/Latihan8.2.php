<?php
Class manusia{
    //property
    var $nama;
    var $warna;

    //method construct di jalankan pertama kali
    function __construct(){
        echo "ini adalah isi Method construct <br/>";
    }


    //Method destruct di jalankan terakhir
    function __destruct (){
        echo "ini adalah isi Method destruct <br/>";
    }

    //Method manusia
    function tampilkan_nama(){
        return "Nama saya Regina seorang Mahasiswa SI <br/>";
        }
}
//instansiasi class manusia
$manusia = new manusia();

//Memanggil Method tampilakna_nama dari class manusia
echo $manusia->tampilkan_nama();

?>