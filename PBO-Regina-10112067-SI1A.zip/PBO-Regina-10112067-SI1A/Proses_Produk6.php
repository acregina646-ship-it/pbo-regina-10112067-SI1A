<?php

function formatRupiah($angka){
    return "Rp " . number_format($angka,0,",",".");
}

class BelanjaWarung {

    public $nama;
    public $barang;
    public $harga;
    public $jumlah;
    public $member;

    function subtotal(){
        return $this->harga * $this->jumlah;
    }

    function diskon($subtotal){

        $diskon = 0;

        if($this->member == 1){
            if($subtotal > 500000){
                $diskon = 50000;
            }
            elseif($subtotal > 100000){
                $diskon = 15000;
            }
        }else{
            if($subtotal > 100000){
                $diskon = 5000;
            }
        }

        return $diskon;
    }

    function total(){
        $subtotal = $this->subtotal();
        $diskon = $this->diskon($subtotal);
        return $subtotal - $diskon;
    }
}

// menerims data dari form (array)

$nama   = $_POST['nama'];
$barang = $_POST['barang'];
$harga  = $_POST['harga'];
$jumlah = $_POST['jumlah'];
$member = $_POST['member'];

echo "<h2>Hasil Data Belanja</h2>";

echo "<table border='1' cellpadding='6'>";

echo "<tr>
<th>No</th>
<th>Nama</th>
<th>Member</th>
<th>Barang</th>
<th>Subtotal</th>
<th>Diskon</th>
<th>Total</th>
</tr>";

$no = 1;

for($i=0; $i<count($nama); $i++){

    $belanja = new BelanjaWarung();

    $belanja->nama   = $nama[$i];
    $belanja->barang = $barang[$i];
    $belanja->harga  = $harga[$i];
    $belanja->jumlah = $jumlah[$i];
    $belanja->member = $member[$i];

    $subtotal = $belanja->subtotal();
    $diskon   = $belanja->diskon($subtotal);
    $total    = $belanja->total();

    echo "<tr>";

    echo "<td>".$no."</td>";
    echo "<td>".$belanja->nama."</td>";
    echo "<td>".($belanja->member ? "Ya" : "Tidak")."</td>";
    echo "<td>".$belanja->barang."</td>";
    echo "<td>".formatRupiah($subtotal)."</td>";
    echo "<td>".formatRupiah($diskon)."</td>";
    echo "<td>".formatRupiah($total)."</td>";

    echo "</tr>";

    $no++;
}

echo "</table>";

?>
<?php
class Produk {
    public $nama;
    public $harga;
    public $stok;

    public function __construct($nama, $harga, $stok) {
        $this->nama = $nama;
        $this->harga = $harga;
        $this->stok = $stok;
    }
}

class Toko {
    public $daftarProduk = [];

    public function __construct() {
        $this->daftarProduk[] = new Produk("Mobil", 8000000, 5);
        $this->daftarProduk[] = new Produk("Motor", 150000, 12);
        $this->daftarProduk[] = new Produk("Sepeda", 300000, 8);
    }

    public function tampilkan() {
        echo "\n===== DATA PRODUK =====\n";
        if (count($this->Produk) == 0) {
            echo "Belum ada produk.\n";
            return;
        }
        echo "No | Nama Produk | Harga | Stok\n";
        echo "-----------------------------\n";
        foreach ($this->daftarProduk as $i => $p) {
            $no = $i + 1;
            echo "$no  | {$p->nama}   | {$p->harga} | {$p->stok}\n";
        }
    }

    public function tambah($nama, $harga, $stok) {
        $this->daftarProduk[] = new Produk($nama, $harga, $stok);
        echo "Produk '$nama' berhasil ditambahkan.\n";
    }

    public function update($nomor, $nama, $harga, $stok) {
        $index = $nomor - 1;
        if (isset($this->daftarProduk[$index])) {
            $this->daftarProduk[$index]->nama = $nama;
            $this->daftarProduk[$index]->harga = $harga;
            $this->daftarProduk[$index]->stok = $stok;
            echo "Produk nomor $nomor berhasil diupdate.\n";
        } else {
            echo "Nomor produk tidak valid.\n";
        }
    }

    public function hapus($nomor) {
        $index = $nomor - 1;
        if (isset($this->daftarProduk[$index])) {
          
        array_splice($this->daftarProduk, $index, 1);
            echo "Produk nomor $nomor berhasil dihapus.\n";
        } else {
            echo "Nomor produk tidak valid.\n";
        }
    }
}

$toko = new Toko();

while (true) {
    echo "\n===== MENU TOKO =====\n";
    echo "1. Tampilkan Data Produk\n";
    echo "2. Tambah Produk\n";
    echo "3. Update Produk\n";
    echo "4. Hapus Produk\n";
    echo "5. Keluar\n";
    echo "Pilih menu: ";
    $pilih = trim(fgets(STDIN));

    switch ($pilih) {
        case '1':
            $toko->tampilkan();
            break;
        case '2':
            echo "Masukkan nama produk: ";
            $nama = trim(fgets(STDIN));
            echo "Masukkan harga: ";
            $harga = (int) trim(fgets(STDIN));
            echo "Masukkan stok: ";
            $stok = (int) trim(fgets(STDIN));
            $toko->tambah($nama, $harga, $stok);
            break;
        case '3':
            $toko->tampilkan();

            echo "Pilih nomor produk yang akan diupdate: ";
           
            $no = (int) trim(fgets(STDIN));
            echo "Nama baru: ";
            $nama = trim(fgets(STDIN));
            echo "Harga baru: ";
            $harga = (int) trim(fgets(STDIN));
            echo "Stok baru: ";
            $stok = (int) trim(fgets(STDIN));
            $toko->update($no, $nama, $harga, $stok);
            break;
        case '4':
            
            $toko->tampilkan();
            echo "Pilih nomor produk yang akan dihapus: ";
            $no = (int) trim(fgets(STDIN));
            $toko->hapus($no);
            break;
        case '5':
            echo "\n";
            exit;
        default:
            echo "Pilihan tidak tersedia, silakan coba lagi.\n";
    }
}
?>