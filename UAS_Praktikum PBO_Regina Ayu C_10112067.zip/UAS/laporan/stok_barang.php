<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Stok Barang</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
  

</head>
<body>
    <div class="judul">		
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Laporan Stok Barang</h2>
    </div>

    <div class="menu no-print">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="stok_barang.php">Laporan Stok</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

   
        <h3>Laporan Stok Barang</h3>
        <p>Tanggal: <?php echo date('d/m/Y H:i:s'); ?></p>
        
        <table border="1" class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Barang</th>
                    <th>Nama Barang</th>
                    <th>Jenis</th>
                    <th>Stok</th>
                    <th>Satuan</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = mysqli_query($koneksi, "SELECT b.*, j.jenis, j.satuan FROM tb_barang b LEFT JOIN tb_jenis j ON b.kode_jenis = j.kode_jenis ORDER BY b.nama_barang");
                $nomor = 1;
                while($data = mysqli_fetch_array($query)){
                    $status = ($data['stok'] < 10) ? "Stok Menipis" : "Stok Aman";
                    $warna = ($data['stok'] < 10) ?  : "";
                ?>
                <tr <?php echo $warna; ?>>
                    <td><?php echo $nomor++; ?></td>
                    <td><?php echo $data['kd_barang']; ?></td>
                    <td><?php echo $data['nama_barang']; ?></td>
                    <td><?php echo $data['jenis']; ?></td>
                    <td><?php echo $data['stok']; ?></td>
                    <td><?php echo $data['satuan']; ?></td>
                    <td><?php echo $status; ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        
        <br>
        <p><strong>Catatan:</strong> Stok yang berwarna merah adalah stok yang menipis (kurang dari 10).</p>
    </div>
</body>
</html>