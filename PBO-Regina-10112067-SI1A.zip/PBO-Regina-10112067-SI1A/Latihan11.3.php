<?php
Class Str{
    private $s='';
    private $function=[
        'length' => 'strlen',
        'upper' => 'strtouper',
        'lower' => 'strlower'
        //map more method to function
    ];

    public function __construct(string $s)
    {
        $this->s = $s;
    }

    public function __call ($method, $args)
    {
        if (!in_array($method, array_keys($this->functions))){

            throw new BadMethodCallException();
    }

    array_unshift ($args, $this->s);
    return call_user_func_array($this->function[$method], $args);
    }
}

$s = new Str('Hello, Word!');
echo $s->upper(). '<br>';
echo $s->lower(). '<br>';
echo $s->length(). '<br>';

?>