<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";

$no_pembelian = $_POST['no_pembelian'];
$tanggal = $_POST['tanggal'];
$id_supplier = $_POST['id_supplier'];
$kd_barang = $_POST['kd_barang'];
$jumlah = $_POST['jumlah'];
$total = $_POST['total'];

$total_barang = 0;
$total_harga = 0;

for($i = 0; $i < count($kd_barang); $i++) {
    $total_barang += $jumlah[$i];
    $total_harga += $total[$i];
}

// Simpan ke tb_pembelian
mysqli_query($koneksi, "INSERT INTO tb_pembelian VALUES('$no_pembelian','$tanggal','$id_supplier',$total_barang,$total_harga)");

// Simpan detail dan update stok
for($i = 0; $i < count($kd_barang); $i++) {
    // Ambil kode_jenis dan harga dari database
    $q = mysqli_query($koneksi, "SELECT kode_jenis, harga_beli FROM tb_barang WHERE kd_barang='{$kd_barang[$i]}'");
    $d = mysqli_fetch_array($q);
    $kode_jenis = $d['kode_jenis'];
    $harga = $d['harga_beli'];
    
    // Simpan detail
    mysqli_query($koneksi, "INSERT INTO detail_pembelian VALUES('$no_pembelian','{$kd_barang[$i]}','$kode_jenis',{$jumlah[$i]},$harga,{$total[$i]},NULL)");
    
    // Update stok barang (tambah stok)
    mysqli_query($koneksi, "UPDATE tb_barang SET stok = stok + {$jumlah[$i]} WHERE kd_barang='{$kd_barang[$i]}'");
}

header("location: index.php?pesan=input");
?>