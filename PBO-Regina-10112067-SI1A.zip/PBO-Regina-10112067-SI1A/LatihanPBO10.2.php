<?php

class TagihanListrik {
    // Properti privat
    private $nama;
    private $kwh;
    private $tarif = 1500; // tarif per kWh

    // Method untuk mengisi data
    public function setData($nama, $kwh) {
        $this->nama = $nama;
        $this->kwh = $kwh;
    }
    
    public function getNama() {
        return $this->nama;
    }

    public function getKwh() {
        return $this->kwh;
    }

    public function hitungTotal() {
        $total = $this->kwh * $this->tarif;
        if ($this->kwh > 1000) {
            $total -= 50000; // diskon jika kWh lebih dari 1000
        }
        return $total;
    }
}
