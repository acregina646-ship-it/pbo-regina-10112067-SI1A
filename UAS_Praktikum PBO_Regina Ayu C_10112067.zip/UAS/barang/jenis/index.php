<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Jenis Barang</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
    <div class="judul">		
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Data Jenis Barang</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Data Jenis</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <h3>Data Jenis Barang</h3>
        
        <table border="1" class="table">
            <tr>
                <th>No</th>
                <th>Kode Jenis</th>
                <th>Jenis</th>
                <th>Satuan</th>
            </tr>
            <?php
            $query = mysqli_query($koneksi, "SELECT * FROM tb_jenis");
            $nomor = 1;
            while($data = mysqli_fetch_array($query)){
            ?>
            <tr>
                <td><?php echo $nomor++; ?></td>
                <td><?php echo $data['kode_jenis']; ?></td>
                <td><?php echo $data['jenis']; ?></td>
                <td><?php echo $data['satuan']; ?></td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>