<!DOCTYPE html>

<html>
<head>
<title>Input Data Belanja</title>
</head>

<body>

<h2>Input Data Belanja</h2>

<form action="Proses_Produk6.php" method="POST">

Nama : <input type="text" name="nama[]"><br><br>

Barang : <input type="text" name="barang[]"><br><br>

Harga : <input type="number" name="harga[]"><br><br>

Jumlah : <input type="number" name="jumlah[]"><br><br>

Member : <select name="member[]">

<option value="1">Ya</option>
<option value="0">Tidak</option>
</select>

<br><br>

<button type="submit">Proses</button>

</form>

</body>
</html>
