<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Input Barang</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
    <div class="judul">
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Input Data Barang</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Data Barang</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <a href="index.php">Kembali</a>
        <h3>Form Input Barang</h3>
        
        <form action="input-aksi.php" method="post">
            <table>
                <tr>
                    <td>Kode Barang</td>
                    <td><input type="text" name="kd_barang" required placeholder="Contoh: BRG99"></td>
                </tr>
                <tr>
                    <td>Nama Barang</td>
                    <td><input type="text" name="nama_barang" required></td>
                </tr>
                <tr>
                    <td>Jenis Barang</td>
                    <td>
                        <select name="kode_jenis" required>
                            <option value="">Pilih Jenis</option>
                            <?php
                            $q_jenis = mysqli_query($koneksi, "SELECT * FROM tb_jenis");
                            while($jenis = mysqli_fetch_array($q_jenis)){
                                echo "<option value='{$jenis['kode_jenis']}'>{$jenis['jenis']} ({$jenis['satuan']})</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Stok</td>
                    <td><input type="number" name="stok" value="0"></td>
                </tr>
                <tr>
                    <td>Harga Beli</td>
                    <td><input type="number" name="harga_beli" required></td>
                </tr>
                <tr>
                    <td>Harga Jual</td>
                    <td><input type="number" name="harga_jual" required></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Simpan"></td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>