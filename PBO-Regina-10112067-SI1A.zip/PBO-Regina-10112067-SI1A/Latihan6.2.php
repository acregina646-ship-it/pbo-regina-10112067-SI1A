<?php
$buah = ["Strowberry", "Mangga", "Apel"];

foreach ($buah as $b) 
{
    echo $b."<br>";
}
?>