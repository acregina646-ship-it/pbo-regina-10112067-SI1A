<?php

function formatRupiah($angka): string {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

class BelanjaWarung{

    public $namaPembeli;
    public $namaBarang;
    public $hargaBarang;
    public $jumlahBeli;

    public function hitungSubtotal(): float|int {
        return $this->hargaBarang * $this->jumlahBeli;
    }

    public function hitungDiskon($subtotal): float|int {
        if ($subtotal > 1000000){
            return $subtotal * 0.1;
        }
        return 0;
    }

    public function hitungTotal(): float|int {
        $subtotal = $this->hitungSubtotal();
        $diskon   = $this->hitungDiskon($subtotal);
        return $subtotal - $diskon;
    }
}

$dataBelanja = [

    [
        "nama"    =>  "Andi",
        "barang"  =>  "Gula 1 Kg",
        "harga"   =>   23000,
        "jumlah"  =>   1
    ],

    [
        "nama"    =>  "Rina",
        "barang"  =>  "Minyak 1 L",
        "harga"   =>   24000,
        "jumlah"  =>   1
    ],

    [ 
        "nama"    =>  "lana",
        "barang"  =>  "Terigu 1 KG",
        "harga"   =>   15000,
        "jumlah"  =>   1
    ]
  
];

echo "<h2>TRANSAKSI 1</h2>";

$errors1 = [];

$nama   =$dataBelanja[0]["nama"];
$barang =$dataBelanja[0]["barang"];
$harga  =$dataBelanja[0]["harga"];
$jumlah =$dataBelanja[0]["jumlah"];


if (empty($nama)){
   $errors1 [] = "Nama pembeli tidak boleh kosong.";
}

if ($harga <= 0){
    $errors1[] = "Harga harus lebih dari 0.";
}

if ($jumlah <= 0){
    $errors1[] = "Jumlah beli harus lebih dari 0.";
}

if (!empty($errors1)){

foreach ($errors1 as $error) {
    echo $error . "<br>";
}

}else{

$belanja1 = new Belanjawarung();
$belanja1->namaPembeli = $nama;
$belanja1->namaBarang  = $barang;
$belanja1->hargaBarang = $harga;
$belanja1->jumlahBeli  = $jumlah;

$subtotal = $belanja1->hitungSubtotal();
$diskon   = $belanja1->hitungDiskon($subtotal);
$total    = $belanja1->hitungTotal();

echo "pembeli : $belanja1->namaPembeli<br>";
echo "barang : $belanja1->namaBarang<br>";
echo "subtotal : ". formatRupiah($subtotal) . "<br>";
echo "diskon : ". formatRupiah($diskon) . "<br>";
echo "<b>total bayar: ". formatRupiah($total) . "</b><br><br>";

}

echo "<h2>TRANSAKSI 2</h2>";

$errors2 = [];

$nama   =$dataBelanja[1]["nama"];
$barang =$dataBelanja[1]["barang"];
$harga  =$dataBelanja[1]["harga"];
$jumlah =$dataBelanja[1]["jumlah"];


if (empty($nama)){
   $errors2 [] = "Nama pembeli tidak boleh kosong.";
}

if ($harga <= 0){
    $errors2 [] = "Harga harus lebih dari 0.";
}

if ($jumlah <= 0){
    $errors2 [] = "Jumlah beli harus lebih dari 0.";
}

if (!empty($errors2)){

foreach ($errors2 as $error) {
    echo $error . "<br>";
}

}else

$belanja2 = new BelanjaWarung();
$belanja2->namaPembeli = $nama;
$belanja2->namaBarang  = $barang;
$belanja2->hargaBarang = $harga;
$belanja2->jumlahBeli  = $jumlah;

$subtotal = $belanja2->hitungSubtotal();
$diskon   = $belanja2->hitungDiskon($subtotal);
$total    = $belanja2->hitungTotal();

echo "pembeli : $belanja2->namaPembeli<br>";
echo "barang : $belanja2->namaBarang<br>";
echo "subtotal : ". formatRupiah($subtotal) . "<br>";
echo "diskon : ". formatRupiah($diskon) . "<br>";
echo "<b>total bayar: ". formatRupiah($total) . "</b><br><br>";


echo "<h2>TRANSAKSI 3</h2>";

$errors2 = [];

$nama   =$dataBelanja[2]["nama"];
$barang =$dataBelanja[2]["barang"];
$harga  =$dataBelanja[2]["harga"];
$jumlah =$dataBelanja[2]["jumlah"];


if (empty($nama)){
   $errors3 [] = "Nama pembeli tidak boleh kosong.";
}

if ($harga <= 0){
    $errors3 [] = "Harga harus lebih dari 0.";
}

if ($jumlah <= 0){
    $errors3 [] = "Jumlah beli harus lebih dari 0.";
}

if (!empty($errors3)){

foreach ($errors3 as $error) {
    echo $error . "<br>";
}

}else{

$belanja3 = new BelanjaWarung();
$belanja3->namaPembeli = $nama;
$belanja3->namaBarang  = $barang;
$belanja3->hargaBarang = $harga;
$belanja3->jumlahBeli  = $jumlah;

$subtotal = $belanja3->hitungSubtotal();
$diskon   = $belanja3->hitungDiskon($subtotal);
$total    = $belanja3->hitungTotal();

echo "pembeli : $belanja3->namaPembeli<br>";
echo "barang : $belanja3->namaBarang<br>";
echo "subtotal : ". formatRupiah($subtotal) . "<br>";
echo "diskon : ". formatRupiah($diskon) . "<br>";
echo "<b>total bayar: ". formatRupiah($total) . "</b><br><br>";

}

?>