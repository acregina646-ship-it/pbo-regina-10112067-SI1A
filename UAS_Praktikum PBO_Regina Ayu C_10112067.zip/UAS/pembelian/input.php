<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";

// Generate nomor pembelian otomatis
$date = date('Ymd');
$query = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tb_pembelian WHERE no_pembelian LIKE 'BUY-$date%'");
$count = mysqli_fetch_array($query);
$no = str_pad($count['total'] + 1, 3, '0', STR_PAD_LEFT);
$no_pembelian = "BUY-{$date}{$no}";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Transaksi Pembelian</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
    <script>
        let itemCount = 0;
        
        function addItem() {
            itemCount++;
            const container = document.getElementById('items-container');
            const newItem = document.createElement('div');
            newItem.className = 'item-row';
            newItem.id = 'item-' + itemCount;
            newItem.innerHTML = `
                <hr>
                <h4>Item ${itemCount}</h4>
                <table width="100%">
                    <tr>
                        <td width="150">Pilih Barang</td>
                        <td>
                            <select name="kd_barang[]" class="barang-select" onchange="hitungTotal(this)" required>
                                <option value="">Pilih Barang</option>
                                <?php
                                $q_barang = mysqli_query($koneksi, "SELECT * FROM tb_barang");
                                while($barang = mysqli_fetch_array($q_barang)){
                                    echo "<option value='{$barang['kd_barang']}' data-harga='{$barang['harga_beli']}' data-jenis='{$barang['kode_jenis']}'>{$barang['kd_barang']} - {$barang['nama_barang']} (Rp " . number_format($barang['harga_beli'],0,',','.') . ")</option>";
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Jumlah</td>
                        <td><input type="number" name="jumlah[]" class="jumlah" onchange="hitungTotal(this)" required></td>
                    </tr>
                    <tr>
                        <td>Total Harga</td>
                        <td><input type="text" name="total[]" class="total" readonly style="background:#f0f0f0"></td>
                    </tr>
                </table>
                <button type="button" onclick="removeItem(${itemCount})">Hapus Item</button>
            `;
            container.appendChild(newItem);
        }
        
        function removeItem(id) {
            const item = document.getElementById('item-' + id);
            if(item) item.remove();
        }
        
        function hitungTotal(element) {
            let row;
            if(element.classList.contains('barang-select')) {
                row = element.closest('.item-row');
            } else {
                row = element.closest('.item-row');
            }
            const select = row.querySelector('.barang-select');
            const harga = select.options[select.selectedIndex].getAttribute('data-harga') || 0;
            const jumlah = row.querySelector('.jumlah').value;
            const total = harga * jumlah;
            row.querySelector('.total').value = total;
        }
    </script>
</head>
<body>
    <div class="judul">
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Transaksi Pembelian Barang</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Pembelian</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <a href="index.php">← Kembali</a>
        <h3>Form Transaksi Pembelian</h3>
        
        <form action="simpan.php" method="post">
            <table width="100%">
                <tr>
                    <td width="150">No Pembelian</td>
                    <td><b><?php echo $no_pembelian; ?></b>
                        <input type="hidden" name="no_pembelian" value="<?php echo $no_pembelian; ?>">
                    </td>
                </tr>
                <tr>
                    <td>Tanggal</td>
                    <td><b><?php echo date('Y-m-d'); ?></b>
                        <input type="hidden" name="tanggal" value="<?php echo date('Y-m-d'); ?>">
                    </td>
                </tr>
                <tr>
                    <td>Supplier</td>
                    <td>
                        <select name="id_supplier" required>
                            <option value="">Pilih Supplier</option>
                            <?php
                            $q_supplier = mysqli_query($koneksi, "SELECT * FROM tb_supplier");
                            while($supplier = mysqli_fetch_array($q_supplier)){
                                echo "<option value='{$supplier['id_supplier']}'>{$supplier['id_supplier']} - {$supplier['nama_supplier']}</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
            </table>
            
            <br>
            <h3>Daftar Barang</h3>
            <div id="items-container">
                <div id="item-0" class="item-row">
                    <h4>Item 1</h4>
                    <table width="100%">
                        <tr>
                            <td width="150">Pilih Barang</td>
                            <td>
                                <select name="kd_barang[]" class="barang-select" onchange="hitungTotal(this)" required>
                                    <option value="">Pilih Barang</option>
                                    <?php
                                    $q_barang = mysqli_query($koneksi, "SELECT * FROM tb_barang");
                                    while($barang = mysqli_fetch_array($q_barang)){
                                        echo "<option value='{$barang['kd_barang']}' data-harga='{$barang['harga_beli']}' data-jenis='{$barang['kode_jenis']}'>{$barang['kd_barang']} - {$barang['nama_barang']} (Rp " . number_format($barang['harga_beli'],0,',','.') . ")</option>";
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>Jumlah</td>
                            <td><input type="number" name="jumlah[]" class="jumlah" onchange="hitungTotal(this)" required></td>
                        </tr>
                        <tr>
                            <td>Total Harga</td>
                            <td><input type="text" name="total[]" class="total" readonly style="background:#f0f0f0"></td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <br>
            <button type="button" onclick="addItem()">+ Tambah Item Barang</button>
            <br><br>
            <input type="submit" value="Simpan Transaksi">
        </form>
    </div>
</body>
</html>