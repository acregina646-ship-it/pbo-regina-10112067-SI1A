<?php

$data = [
    ["nama"=> "Rere","nilai"=>99],
    ["nama"=> "Caca","nilai"=>99],
    ["nama"=> "Ririn","nilai"=>99]

];

echo "<table border='1'";
echo "<tr><th>Nama</th><th>Nilai</th><tr>";

foreach ($data as $d){
        echo "<tr>";
        echo "<td>".$d["nama"]."</td>";
        echo "<td>".$d["nilai"]."</td>";
        echo "</tr>";
    }


echo "</table>";
?>