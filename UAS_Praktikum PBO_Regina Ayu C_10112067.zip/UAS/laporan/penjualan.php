<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Penjualan</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
    <style>
        @media print {
            .no-print { display: none; }
        }
        .print-btn {
            padding: 8px 15px;
            margin: 10px 0;
            cursor: pointer;
            background: #9fd6d9;
            border: none;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="judul">		
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Laporan Penjualan</h2>
    </div>

    <div class="menu no-print">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="penjualan.php">Laporan Penjualan</a></li>
            </ul>
        </div>
    </div>


        <h3>Laporan Penjualan</h3>
        <p>Tanggal: <?php echo date('d/m/Y H:i:s'); ?></p>
        
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>No Penjualan</th>
                    <th>Tanggal</th>
                    <th>Customer</th>
                    <th>Total Barang</th>
                    <th>Total Harga</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = mysqli_query($koneksi, "SELECT p.*, c.nama_customer FROM tb_penjualan p LEFT JOIN tb_customer c ON p.id_customer = c.id_customer ORDER BY p.tanggal_penjualan DESC");
                $nomor = 1;
                while($data = mysqli_fetch_array($query)){
                ?>
                <tr>
                    <td><?php echo $nomor++; ?></td>
                    <td><?php echo $data['no_penjualan']; ?></td>
                    <td><?php echo $data['tanggal_penjualan']; ?></td>
                    <td><?php echo $data['nama_customer']; ?></td>
                    <td><?php echo $data['total_barangall']; ?></td>
                    <td>Rp <?php echo number_format($data['total_hargaall'],0,',','.'); ?></td>
                </tr>
                <?php } ?>
                
                <?php if(mysqli_num_rows($query) == 0){ ?>
                <tr>
                    <td colspan="6" style="text-align:center">Belum ada data penjualan</td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>