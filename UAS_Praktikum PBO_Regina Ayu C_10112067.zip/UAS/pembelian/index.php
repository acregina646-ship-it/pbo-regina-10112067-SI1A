<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Pembelian</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
    <div class="judul">		
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Data Pembelian Barang</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Pembelian</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <?php
        if(isset($_GET['pesan'])){
            if($_GET['pesan'] == "input") echo "<div style='background:#d4edda; color:#155724; padding:10px; margin-bottom:10px;'>Transaksi berhasil disimpan.</div>";
        }
        ?>
        
        <a class="tombol" href="input.php">+ Transaksi Pembelian Baru</a>
        
        <h3>Data Pembelian</h3>
        
        <table border="1" class="table" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No Pembelian</th>
                    <th>Tanggal</th>
                    <th>Supplier</th>
                    <th>Total Barang</th>
                    <th>Total Harga</th>
                    <th>Detail</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = mysqli_query($koneksi, "SELECT p.*, s.nama_supplier FROM tb_pembelian p LEFT JOIN tb_supplier s ON p.id_supplier = s.id_supplier ORDER BY p.tanggal_pembelian DESC");
                $nomor = 1;
                while($data = mysqli_fetch_array($query)){
                ?>
                <tr>
                    <td><?php echo $nomor++; ?></td>
                    <td><?php echo $data['no_pembelian']; ?></td>
                    <td><?php echo $data['tanggal_pembelian']; ?></td>
                    <td><?php echo $data['nama_supplier']; ?></td>
                    <td><?php echo $data['total_barangall']; ?> pcs</td>
                    <td>Rp <?php echo number_format($data['total_hargaall'],0,',','.'); ?></td>
                    <td><a href="detail.php?id=<?php echo $data['no_pembelian']; ?>">Lihat Detail</a></td>
                </tr>
                <?php } ?>
                
                <?php if(mysqli_num_rows($query) == 0){ ?>
                <tr>
                    <td colspan="7" style="text-align:center">Belum ada data pembelian</td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>