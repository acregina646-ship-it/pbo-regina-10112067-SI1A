<?php

// KELAS INDUK KARYAWAN
class Karyawan {
    // variabel untuk menyimpan data dasar tiap karyawan
    public $nama;
    public $golongan;
    public $jam;

    // Fungsi otomatis untuk langsung memasukkan nama, golongan, dan jam kerja saat objek dibuat
    public function __construct($nama, $golongan, $jam) {
        $this->nama = $nama;
        $this->golongan = $golongan;
        $this->jam = $jam;
    }

    // Fungsi untuk mencocokkan kode golongan dengan nominal gaji pokoknya
    public function getGajiPokok() {
        // Daftar tabel gaji berdasarkan golongan (menggunakan struktur Array)
        $gaji = [
            "Ib"=>1250000, "Ic"=>1300000, "Id"=>1350000,
            "IIa"=>2000000, "IIb"=>2100000, "IIc"=>2200000, "IId"=>2300000,
            "IIIa"=>2400000, "IIIb"=>2500000, "IIIc"=>2600000, "IIId"=>2700000,
            "IVa"=>2800000, "IVb"=>2900000, "IVc"=>3000000, "IVd"=>3100000
        ];

        // Mengembalikan nilai gaji pokok yang sesuai dengan golongan si karyawan
        return $gaji[$this->golongan];
    }

    // Fungsi untuk menghitung total pendapatan (Gaji Pokok + Uang Lembur)
    public function getTotalGaji() {
        $lembur = $this->jam * 15000; // Tarif lemburnya rata, yaitu Rp 15.000 per jam
        return $this->getGajiPokok() + $lembur; // Totalnya adalah gaji pokok ditambah hasil lembur
    }
}

// BUKU CATATAN UTAMA (Array kosong buat nampung daftar objek karyawan)
$data = [];

// Memasukkan 3 data karyawan awal ke dalam list
$data[] = new Karyawan("Winny","IIb",30);
$data[] = new Karyawan("Stendy","IIIc",32);
$data[] = new Karyawan("Alfred","IVb",30);

// PROSES PERULANGAN MENU (Akan terus berputar sampai pengguna memilih menu nomor 5)
do {
    // Menampilkan teks pilihan menu di terminal/command prompt
    echo "\n===== MENU GAJI KARYAWAN =====\n";
    echo "1. Tampilkan Data\n";
    echo "2. Tambah Data\n";
    echo "3. Update Data\n";
    echo "4. Hapus Data\n";
    echo "5. Keluar\n";
    echo "Pilih menu: ";

    // Mengambil input ketikan angka dari pengguna di terminal, lalu dibersihkan spasinya pakai trim()
    $menu = trim(fgets(STDIN));

    //  MENU 1: MENAMPILKAN DATA 
    if ($menu == 1) {
        echo "\n===== DATA GAJI KARYAWAN =====\n";
        echo "No | Nama | Golongan | Jam Lembur | Total Gaji\n";

        $no = 1; // Untuk penomoran urut dari angka 1
        // Membaca isi list data karyawan satu per satu
        foreach ($data as $k) {
            // Menampilkan data ke layar. Angka total gaji dirapikan menggunakan format rupiah.
            echo $no++ . " | " . $k->nama . " | " . $k->golongan . " | " . $k->jam . " | Rp" . number_format($k->getTotalGaji(),0,',','.') . "\n";
        }

    // MENU 2: MENAMBAH DATA BARU 
    } elseif ($menu == 2) {
        // Meminta input data karyawan baru dari terminal
        echo "Nama: ";
        $nama = trim(fgets(STDIN));

        echo "Golongan: ";
        $gol = trim(fgets(STDIN));

        echo "Jam lembur: ";
        $jam = trim(fgets(STDIN));

        // Membuat objek Karyawan baru dari inputan tadi, lalu dimasukkan ke dalam list $data
        $data[] = new Karyawan($nama,$gol,$jam);
        echo "Data ditambahkan\n";

    //  MENU 3: MENGUBAH DATA YANG SUDAH ADA 
    } elseif ($menu == 3) {
        echo "Pilih nomor: ";
        // Dikurangi 1 karena urutan data di komputer (indeks) selalu dimulai dari angka 0, bukan 1
        $i = trim(fgets(STDIN)) - 1;

        // Memastikan apakah nomor data yang dipilih memang ada di dalam list
        if (isset($data[$i])) {
            // Meminta inputan baru untuk langsung menimpa data lama karyawan tersebut
            echo "Nama baru: ";
            $data[$i]->nama = trim(fgets(STDIN));

            echo "Golongan baru: ";
            $data[$i]->golongan = trim(fgets(STDIN));

            echo "Jam baru: ";
            $data[$i]->jam = trim(fgets(STDIN));

            echo "Data diupdate\n";
        }

    //  MENU 4: MENGHAPUS DATA 
    } elseif ($menu == 4) {
        echo "Pilih nomor: ";
        $i = trim(fgets(STDIN)) - 1; // Dikurangi 1 untuk menyesuaikan urutan indeks komputer

        // Memastikan apakah nomor data yang ingin dihapus memang ada di dalam list
        if (isset($data[$i])) {
            unset($data[$i]); // Menghapus data karyawan pada posisi tersebut
            $data = array_values($data); // Mengurutkan ulang kunci nomor indeks agar tidak ada nomor yang melompat/bolong
            echo "Data dihapus\n";
        }

    //  MENU 5: KELUAR 
    } elseif ($menu == 5) {
        echo "Selesai\n";
    }

} while ($menu != 5); // Selama pilihan menu BUKAN angka 5, program akan terus memunculkan menu utama kembali

?>