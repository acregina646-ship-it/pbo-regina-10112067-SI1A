<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";

$id = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM tb_barang WHERE kd_barang='$id'");
$data = mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Barang</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
    <div class="judul"><?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";

$id = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM tb_supplier WHERE id_supplier='$id'");
$data = mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Supplier</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
    <div class="judul">
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Edit Data Supplier</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Data Supplier</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <form action="update.php" method="post">
            <input type="hidden" name="id_supplier" value="<?php echo $data['id_supplier']; ?>">
            <table>
                <tr>
                    <td>ID Supplier</td>
                    <td><b><?php echo $data['id_supplier']; ?></b></td>
                </tr>
                <tr>
                    <td>Nama Supplier</td>
                    <td><input type="text" name="nama_supplier" value="<?php echo $data['nama_supplier']; ?>"></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td><textarea name="alamat_supplier" rows="3" style="width:100%"><?php echo $data['alamat_supplier']; ?></textarea></td>
                </tr>
                <tr>
                    <td>Telepon</td>
                    <td><input type="text" name="telepon_supplier" value="<?php echo $data['telepon_supplier']; ?>"></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><input type="email" name="email_supplier" value="<?php echo $data['email_supplier']; ?>"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Update"></td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Edit Data Barang</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Data Barang</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <form action="update.php" method="post">
            <input type="hidden" name="kd_barang" value="<?php echo $data['kd_barang']; ?>">
            <table>
                <tr>
                    <td>Kode Barang</td>
                    <td><b><?php echo $data['kd_barang']; ?></b></td>
                </tr>
                <tr>
                    <td>Nama Barang</td>
                    <td><input type="text" name="nama_barang" value="<?php echo $data['nama_barang']; ?>"></td>
                </tr>
                <tr>
                    <td>Jenis Barang</td>
                    <td>
                        <select name="kode_jenis">
                            <?php
                            $q_jenis = mysqli_query($koneksi, "SELECT * FROM tb_jenis");
                            while($jenis = mysqli_fetch_array($q_jenis)){
                                $selected = ($jenis['kode_jenis'] == $data['kode_jenis']) ? "selected" : "";
                                echo "<option value='{$jenis['kode_jenis']}' $selected>{$jenis['jenis']} ({$jenis['satuan']})</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Stok</td>
                    <td><input type="number" name="stok" value="<?php echo $data['stok']; ?>"></td>
                </tr>
                <tr>
                    <td>Harga Beli</td>
                    <td><input type="number" name="harga_beli" value="<?php echo $data['harga_beli']; ?>"></td>
                </tr>
                <tr>
                    <td>Harga Jual</td>
                    <td><input type="number" name="harga_jual" value="<?php echo $data['harga_jual']; ?>"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Update"></td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>