<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";

$id = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM tb_customer WHERE id_customer='$id'");
$data = mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Customer</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
    <div class="judul">
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Edit Data Customer</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Data Customer</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <form action="update.php" method="post">
            <input type="hidden" name="id_customer" value="<?php echo $data['id_customer']; ?>">
            <table>
                <tr>
                    <td>ID Customer</td>
                    <td><b><?php echo $data['id_customer']; ?></b></td>
                </tr>
                <tr>
                    <td>Nama Customer</td>
                    <td><input type="text" name="nama_customer" value="<?php echo $data['nama_customer']; ?>"></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td>
                        <select name="jenis_kelamin">
                            <option value="Laki-laki" <?php echo ($data['jenis_kelamin']=='Laki-laki')?'selected':''; ?>>Laki-laki</option>
                            <option value="Perempuan" <?php echo ($data['jenis_kelamin']=='Perempuan')?'selected':''; ?>>Perempuan</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td><textarea name="alamat_customer" rows="3" style="width:100%"><?php echo $data['alamat_customer']; ?></textarea></td>
                </tr>
                <tr>
                    <td>Telepon</td>
                    <td><input type="text" name="telepon_customer" value="<?php echo $data['telepon_customer']; ?>"></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><input type="email" name="email_customer" value="<?php echo $data['email_customer']; ?>"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Update"></td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>