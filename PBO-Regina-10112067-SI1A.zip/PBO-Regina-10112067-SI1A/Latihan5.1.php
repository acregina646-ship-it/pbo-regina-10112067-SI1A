<?php

$nilai = 110;

if ($nilai >= 100){
    echo "Nilai tidak boleh lebih dari 100";
}elseif ($nilai >= 60){
    echo "Lulus";
}elseif ($nilai <= 60){
    echo "Tidak Lulus";
}else


?>