<?php

class Produk {
    public $nama;
    public $harga;
    public $stok;

    public function __construct($nama, $harga, $stok) {
        $this->nama  = $nama;
        $this->harga = $harga;
        $this->stok  = $stok;
    }
}

class Toko {
    public $daftarProduk = [];

    public function __construct() {
        $this->daftarProduk[] = new Produk("Mobil", 8000000, );
        $this->daftarProduk[] = new Produk("Motor", 150000, );
        $this->daftarProduk[] = new Produk("Sepeda", 300000, );
    }

    public function tampilkan() {
        echo "\n===== DATA PRODUK =====\n";

        if (count($this->daftarProduk) == 0) {
            echo "Belum ada produk.\n";
            return;
        }

        echo "No | Nama Produk | Harga | Stok\n";
        echo "-------------------------------\n";

        $i = 0;
        while ($i < count($this->daftarProduk)) {
            $p = $this->daftarProduk[$i];
            $no = $i + 1;
            echo "$no | {$p->nama} | {$p->harga} | {$p->stok}\n";
            $i++;
        }
    }

    public function tambah($nama, $harga, $stok) {
        $this->daftarProduk[] = new Produk($nama, $harga, $stok);
        echo "Produk '$nama' berhasil ditambahkan.\n";
    }

    public function update($nomor, $nama, $harga, $stok) {
        $index = $nomor - 1;

        if (isset($this->daftarProduk[$i])) {
            $this->daftarProduk[$i]->nama  = $nama;
            $this->daftarProduk[$i]->harga = $harga;
            $this->daftarProduk[$i]->stok  = $stok;
            echo "Produk nomor $nomor berhasil diupdate.\n";
        } else {
            echo "Nomor produk tidak valid.\n";
        }
    }

    public function hapus($nomor) {
        $i = $nomor - 1;

        if (isset($this->daftarProduk[$i])) {
            array_splice($this->daftarProduk, $i, 1);
            echo "Produk nomor $nomor berhasil dihapus.\n";
        } else {
            echo "Nomor produk tidak valid.\n";
        }
    }
}

// PROGRAM UTAMA
$toko = new Toko();

while (true) {
    echo "\n===== MENU TOKO =====\n";
    echo "1. Tampilkan Data Produk\n";
    echo "2. Tambah Produk\n";
    echo "3. Update Produk\n";
    echo "4. Hapus Produk\n";
    echo "5. Keluar\n";
    echo "Pilih menu: ";

    $pilih = trim(fgets(STDIN));
    $jalan = true;
    while ($jalan) {

        if ($pilih == '1') {
            $toko->tampilkan();
            $jalan = false;

        } elseif ($pilih == '2') {
            echo "Masukkan nama produk: ";
            $nama = trim(fgets(STDIN));

            echo "Masukkan harga: ";
            $harga = (int) trim(fgets(STDIN));

            echo "Masukkan stok: ";
            $stok = (int) trim(fgets(STDIN));

            $toko->tambah($nama, $harga, $stok);
            $jalan = false;

        } elseif ($pilih == '3') {
            $toko->tampilkan();

            echo "Pilih nomor produk: ";
            $no = (int) trim(fgets(STDIN));

            echo "Nama baru: ";
            $nama = trim(fgets(STDIN));

            echo "Harga baru: ";
            $harga = (int) trim(fgets(STDIN));

            echo "Stok baru: ";
            $stok = (int) trim(fgets(STDIN));

            $toko->update($no, $nama, $harga, $stok);
            $jalan = false;

        } elseif ($pilih == '4') {
            $toko->tampilkan();

            echo "Pilih nomor produk: ";
            $no = (int) trim(fgets(STDIN));

            $toko->hapus($no);
            $jalan = false;

        } elseif ($pilih == '5') {
            echo "Program selesai.\n";
            exit;

        } else {
            echo "Pilihan tidak tersedia.\n";
            $jalan = false;
        }
    }
}
?>