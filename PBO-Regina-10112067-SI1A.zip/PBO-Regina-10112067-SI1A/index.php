<?php 
require_once "TagihanListrik.php";
require_once "TagihanRepository.php";

function formatRupiah ($angka){
    // Menggunakan '.' untuk ribuan agar sesuai standar Indonesia
    return "Rp " . number_format($angka, 0, ',', '.');
}

// Logika (ALUR PROGRAM)
$repo = new TagihanRepository(); // Pastikan nama class sesuai dengan di file Repository
$data = $repo->getAll();

$hasil = [];

foreach ($data as $d){
    $obj = new TagihanListrik();
    // Gunakan quotes pada key array: "nama" dan "kwh"
    $obj->setData($d["nama"], $d["kwh"]);

    $hasil[] = [
        "nama"  => $obj->getNama(),
        "kwh"   => $d["kwh"],
        "total" => $obj->hitungTotal()
    ];
}

// VIEW (OUTPUT)
echo "<h2>DATA TAGIHAN LISTRIK</h2>";
echo "<table border='1' cellpadding='6' cellspacing='0'>"; // Tambah cellspacing agar lebih rapi
echo "<tr>
        <th>No</th>
        <th>Nama</th>
        <th>Pemakaian (kWh)</th>
        <th>Total Bayar</th>
      </tr>";

$no = 1;
foreach ($hasil as $h){
    echo "<tr>";
    echo "<td>" . $no++ . "</td>";
    echo "<td>" . $h["nama"] . "</td>";
    echo "<td>" . $h["kwh"] . "</td>"; // Perhatikan case-sensitive: "kwh" bukan "kWh"
    echo "<td>" . formatRupiah($h["total"]) . "</td>";
    echo "</tr>";
}

// PINDAHKAN Tag tutup table ke luar foreach
echo "</table>"; 
?>