<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Jenis Barang</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
    <div class="judul">		
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Data Jenis Barang</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Data Jenis</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <h3>Data Jenis Barang</h3>
        
        <table border="1" class="table" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Jenis</th>
                    <th>Jenis Barang</th>
                    <th>Satuan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = mysqli_query($koneksi, "SELECT * FROM tb_jenis ORDER BY kode_jenis");
                
                if(!$query){
                    echo "<tr><td colspan='4' style='color:red;'>Error Query: " . mysqli_error($koneksi) . "</td></tr>";
                } else {
                    $nomor = 1;
                    while($data = mysqli_fetch_array($query)){
                ?>
                <tr>
                    <td><?php echo $nomor++; ?></td>
                    <td><?php echo $data['kode_jenis']; ?></td>
                    <td><?php echo $data['jenis']; ?></td>
                    <td><?php echo $data['satuan']; ?></td>
                </tr>
                <?php 
                    }
                    
                    if(mysqli_num_rows($query) == 0){
                        echo "<tr><td colspan='4' style='text-align:center;'>Tidak ada data jenis barang</td></tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>