<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";

$kd_barang = $_POST['kd_barang'];
$kode_jenis = $_POST['kode_jenis'];
$nama_barang = $_POST['nama_barang'];
$stok = $_POST['stok'];
$harga_beli = $_POST['harga_beli'];
$harga_jual = $_POST['harga_jual'];

mysqli_query($koneksi, "UPDATE tb_barang SET kode_jenis='$kode_jenis', nama_barang='$nama_barang', stok=$stok, harga_beli=$harga_beli, harga_jual=$harga_jual WHERE kd_barang='$kd_barang'");

header("location: index.php?pesan=update");
?>