<?php
require_once 'config/Database.php';

class Jenis {
    private $db;
    private $table = 'tb_jenis';

    public function __construct() {
        $this->db = new Database();
    }

    public function getAll() {
        $result = $this->db->query("SELECT * FROM {$this->table}");
        return $this->db->fetchAll($result);
    }

    public function getById($kode_jenis) {
        $kode_jenis = $this->db->escape($kode_jenis);
        $result = $this->db->query("SELECT * FROM {$this->table} WHERE kode_jenis='$kode_jenis'");
        return $this->db->fetchOne($result);
    }
}
?>