<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";

try{
    $id = $_GET['id'];
    mysqli_query($koneksi, "DELETE FROM tb_barang WHERE kd_barang='$id'");
    header("location: index.php?pesan=hapus");
    
} catch(Exception $e){
    echo "Error: " . $e->getMessage();
}
?>