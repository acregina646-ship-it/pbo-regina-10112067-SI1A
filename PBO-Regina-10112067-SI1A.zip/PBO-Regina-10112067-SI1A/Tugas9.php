<?php

// CLASS INDUK (Encapsulation)
class TabunganSekolah {
    protected $nama;     // bisa diakses oleh class turunan
    private $saldo;      // hanya bisa diakses di dalam class ini

    // constructor (inisialisasi data awal)
    public function __construct($nama, $saldo_awal) {
        $this->nama = $nama;
        $this->saldo = $saldo_awal;
    }

    // getter saldo (mengambil nilai saldo)
    public function getSaldo() {
        return $this->saldo;
    }

    // getter nama
    public function getNama() {
        return $this->nama;
    }

    // setter saldo (mengubah nilai saldo)
    public function setSaldo($saldo) {
        $this->saldo = $saldo;
    }

    // method setor (menambah saldo)
    public function setor($jumlah) {
        $this->saldo += $jumlah;
    }

    // method tarik (mengurangi saldo dengan pengecekan)
    public function tarik($jumlah) {
        if ($jumlah <= $this->saldo) {
            $this->saldo -= $jumlah;
        } else {
            echo "Saldo " . $this->nama . " tidak cukup!\n";
        }
    }
}


// CLASS ANAK (Inheritance)

// siswa 1 bisa akses saldo sendiri
class Siswa1 extends TabunganSekolah {
    public function lihatSaldoSendiri() {
        return $this->getSaldo(); // akses lewat getter
    }
}

// siswa 2 dibatasi aksesnya
class Siswa2 extends TabunganSekolah {
    public function lihatSaldoSendiri() {
        return "Akses dibatasi!";
    }
}

// siswa 3 dibatasi aksesnya
class Siswa3 extends TabunganSekolah {
    public function lihatSaldoSendiri() {
        return "Akses dibatasi!";
    }
}


// ARRAY OBJEK (menyimpan banyak objek siswa)
$siswa = [
    new Siswa1("Siswa 1", 100000),
    new Siswa2("Siswa 2", 150000),
    new Siswa3("Siswa 3", 200000)
];


// MENAMPILKAN SALDO AWAL (perulangan)
echo "=== SALDO AWAL ===\n";
foreach ($siswa as $s) {
    echo $s->getNama() . " : " . $s->getSaldo() . "\n";
}


// TRANSAKSI (perulangan + percabangan)
echo "\n=== TRANSAKSI ===\n";

foreach ($siswa as $s) {

    $s->setor(50000); // tambah saldo

    // percabangan (cek saldo)
    if ($s->getSaldo() > 100000) {
        $s->tarik(30000);
    } else {
        $s->tarik(10000);
    }
}


// MENAMPILKAN SALDO AKHIR
echo "\n=== SALDO AKHIR ===\n";
foreach ($siswa as $s) {
    echo $s->getNama() . " : " . $s->getSaldo() . "\n";
}


echo "\n=== HAK AKSES ===\n";
echo "Siswa1 : " . $siswa[0]->lihatSaldoSendiri() . "\n";
echo "Siswa2 : " . $siswa[1]->lihatSaldoSendiri() . "\n";
echo "Siswa3 : " . $siswa[2]->lihatSaldoSendiri() . "\n";


// FILE HANDLING (membaca file)
echo "\n=== DATA FILE ===\n";

$file = fopen("tabungan.txt", "r"); // buka file

if ($file) {
    while (($baris = fgets($file)) !== false) { // baca per baris
        echo $baris;
    }
    fclose($file); // tutup file
} else {
    echo "File tidak ditemukan!\n";
}

?>