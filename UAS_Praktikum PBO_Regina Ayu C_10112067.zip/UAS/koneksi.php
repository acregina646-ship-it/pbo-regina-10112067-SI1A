<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "db_inventory";

$koneksi = mysqli_connect($host, $username, $password, $database);

if(!$koneksi){
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Set charset agar tidak error dengan huruf Indonesia
mysqli_set_charset($koneksi, "utf8mb4");
?>