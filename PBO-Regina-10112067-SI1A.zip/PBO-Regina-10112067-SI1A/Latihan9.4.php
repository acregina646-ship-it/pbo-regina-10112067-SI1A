<?php
// Buat class komputer
class komputer {
    // Diubah ke 'protected' agar bisa diakses oleh class turunan (laptop)
    protected $jenis_processor = "Intel Core i7-4790 3.6GHz";
    protected $jenis_RAM = "DDR 4";
    public $jenis_VGA = "PCI Express";

    public function tampilkan_processor() {
        return $this->jenis_processor;
    }

    public function tampilkan_jenisprocessor() {
        return $this->jenis_processor;
    }

    // Diubah ke 'protected' agar bisa dipanggil oleh class laptop
    protected function tampilkan_ram() {
        return $this->jenis_RAM;
    }

    protected function tampilkan_vga() {
        return $this->jenis_VGA;
    }

    public function tampilkan_vga2() {
        return $this->jenis_VGA;
    }
}

// Buat class laptop
class laptop extends komputer {

    public function display_processor() {
        return $this->jenis_processor;
    }

    public function display_processor2() {
        return $this->tampilkan_processor();
    }

    public function display_ram() {
        return $this->jenis_RAM;
    }

    public function display_ram2() {
        return $this->tampilkan_ram();
    }

    public function display_vga() {
        return $this->tampilkan_vga();
    }

    // Diubah ke 'public' agar bisa dipanggil dari luar (objek)
    public function display_processorkomputer() {
        return $this->jenis_processor;
    }
}

// Instansiasi objek
$komputer = new komputer();
$laptop = new laptop();

// Menjalankan method
echo "Line 61 : " . $komputer->tampilkan_processor() . "\n";
echo "Line 62 : " . $laptop->display_processor() . "\n";
echo "Line 63 : " . $laptop->display_processor2() . "\n";
echo "Line 64 : " . $laptop->tampilkan_jenisprocessor() . "\n";
echo "Line 65 : " . $laptop->display_ram() . "\n";
// Gunakan tampilkan_vga2 karena tampilkan_vga bersifat protected
echo "Line 66 : " . $laptop->tampilkan_vga2() . "\n"; 
echo "Line 67 : " . $laptop->display_processorkomputer() . "\n";

?>
