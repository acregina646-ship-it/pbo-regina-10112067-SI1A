<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";

$no_penjualan = $_GET['id'];
$penjualan = mysqli_fetch_array(mysqli_query($koneksi, "SELECT p.*, c.nama_customer FROM tb_penjualan p LEFT JOIN tb_customer c ON p.id_customer = c.id_customer WHERE p.no_penjualan='$no_penjualan'"));
?>
<!DOCTYPE html>
<html>
<head>
    <title>Detail Penjualan</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
    <div class="judul">		
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Detail Penjualan</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Penjualan</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <a href="index.php">← Kembali</a>
        
        <h3>Detail Penjualan: <?php echo $no_penjualan; ?></h3>
        
        <table border="0" width="100%">
            <tr><td width="150">Tanggal</td><td>: <?php echo $penjualan['tanggal_penjualan']; ?></td></tr>
            <tr><td>Customer</td><td>: <?php echo $penjualan['nama_customer']; ?></td></tr>
            <tr><td>Total Barang</td><td>: <?php echo $penjualan['total_barangall']; ?> pcs</td></tr>
            <tr><td>Total Harga</td><td>: Rp <?php echo number_format($penjualan['total_hargaall'],0,',','.'); ?></td></tr>
        </table>
        
        <br>
        <h4>Daftar Barang</h4>
        
        <table border="1" class="table" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Barang</th>
                    <th>Nama Barang</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = mysqli_query($koneksi, "SELECT d.*, b.nama_barang FROM detail_penjualan d LEFT JOIN tb_barang b ON d.kd_barang = b.kd_barang WHERE d.no_penjualan='$no_penjualan'");
                $nomor = 1;
                while($data = mysqli_fetch_array($query)){
                ?>
                <tr>
                    <td><?php echo $nomor++; ?></td>
                    <td><?php echo $data['kd_barang']; ?></td>
                    <td><?php echo $data['nama_barang']; ?></td>
                    <td><?php echo $data['jumlah_barang']; ?> pcs</td>
                    <td>Rp <?php echo number_format($data['harga_barang'],0,',','.'); ?></td>
                    <td>Rp <?php echo number_format($data['total_harga'],0,',','.'); ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>