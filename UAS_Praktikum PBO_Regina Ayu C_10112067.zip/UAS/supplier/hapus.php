<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";

$id = $_GET['id'];
mysqli_query($koneksi, "DELETE FROM tb_supplier WHERE id_supplier='$id'");

header("location: index.php?pesan=hapus");
?>