<?php
require_once dirname(__DIR__) . '/config/Database.php';

class Barang {
    private $db;
    private $table = 'tb_barang';

    public function __construct() {
        $this->db = new Database();
    }

    public function getAll() {
        $sql = "SELECT b.*, j.jenis, j.satuan 
                FROM {$this->table} b 
                LEFT JOIN tb_jenis j ON b.kode_jenis = j.kode_jenis 
                ORDER BY b.kd_barang";
        $result = $this->db->query($sql);
        return $this->db->fetchAll($result);
    }

    public function getById($kd_barang) {
        $kd_barang = $this->db->escape($kd_barang);
        $sql = "SELECT b.*, j.jenis, j.satuan 
                FROM {$this->table} b 
                LEFT JOIN tb_jenis j ON b.kode_jenis = j.kode_jenis 
                WHERE b.kd_barang = '$kd_barang'";
        $result = $this->db->query($sql);
        return $this->db->fetchOne($result);
    }

    public function create($data) {
        $kd_barang = $this->db->escape($data['kd_barang']);
        $kode_jenis = $this->db->escape($data['kode_jenis']);
        $nama_barang = $this->db->escape($data['nama_barang']);
        $stok = (int)$data['stok'];
        $harga_beli = (int)$data['harga_beli'];
        $harga_jual = (int)$data['harga_jual'];
        $gambar = $this->db->escape($data['gambar_produk'] ?? '');

        $sql = "INSERT INTO {$this->table} 
                VALUES ('$kd_barang', '$kode_jenis', '$nama_barang', 
                        $stok, $harga_beli, $harga_jual, '$gambar')";
        return $this->db->query($sql);
    }

    public function update($kd_barang, $data) {
        $kd_barang = $this->db->escape($kd_barang);
        $kode_jenis = $this->db->escape($data['kode_jenis']);
        $nama_barang = $this->db->escape($data['nama_barang']);
        $stok = (int)$data['stok'];
        $harga_beli = (int)$data['harga_beli'];
        $harga_jual = (int)$data['harga_jual'];

        $sql = "UPDATE {$this->table} 
                SET kode_jenis='$kode_jenis', 
                    nama_barang='$nama_barang', 
                    stok=$stok, 
                    harga_beli=$harga_beli, 
                    harga_jual=$harga_jual 
                WHERE kd_barang='$kd_barang'";
        return $this->db->query($sql);
    }

    public function delete($kd_barang) {
        $kd_barang = $this->db->escape($kd_barang);
        $sql = "DELETE FROM {$this->table} WHERE kd_barang='$kd_barang'";
        return $this->db->query($sql);
    }

    public function updateStok($kd_barang, $jumlah, $tipe = 'tambah') {
        $kd_barang = $this->db->escape($kd_barang);
        if($tipe == 'tambah') {
            $sql = "UPDATE {$this->table} SET stok = stok + $jumlah WHERE kd_barang='$kd_barang'";
        } else {
            $sql = "UPDATE {$this->table} SET stok = stok - $jumlah WHERE kd_barang='$kd_barang'";
        }
        return $this->db->query($sql);
    }
}
?>