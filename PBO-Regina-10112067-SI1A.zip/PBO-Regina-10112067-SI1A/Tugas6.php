<?php

class BangunRuang {
    public $jenis;
    public $sisi;
    public $jari;
    public $tinggi;

    function __construct($jenis,$sisi,$jari,$tinggi){
        $this->jenis=$jenis;
        $this->sisi=$sisi;
        $this->jari=$jari;
        $this->tinggi=$tinggi;
    }

    function volume(){
        $pi=3.1416;

        if($this->jenis=="Bola")
            return (4/3)*$pi*pow($this->jari,3);
        elseif($this->jenis=="Kerucut")
            return (1/3)*$pi*pow($this->jari,2)*$this->tinggi;
        elseif($this->jenis=="Limas Segi Empat")
            return (1/3)*pow($this->sisi,2)*$this->tinggi;
        elseif($this->jenis=="Kubus")
            return pow($this->sisi,3);
        elseif($this->jenis=="Tabung")
            return $pi*pow($this->jari,2)*$this->tinggi;
    }
}

$data=[
["Bola",0,7,0],
["Kerucut",0,14,10],
["Limas Segi Empat",8,0,24],
["Kubus",30,0,0],
["Tabung",0,7,10]
];

echo "<table border='1' cellpadding='8' style='border-collapse:collapse;width:80%;text-align:center;'>";

echo "<tr style='background-color:blue;color:white;'>
<th>No</th>
<th>Jenis Bangun Ruang</th>
<th>Sisi</th>
<th>Jari-jari</th>
<th>Tinggi</th>
<th>Volume</th>
</tr>";

$no=1;

foreach($data as $d){

$b=new BangunRuang($d[0],$d[1],$d[2],$d[3]);

echo "<tr>
<td>".$no++."</td>
<td>".$b->jenis."</td>
<td>".$b->sisi."</td>
<td>".$b->jari."</td>
<td>".$b->tinggi."</td>
<td>".$b->volume()."</td>
</tr>";
}

echo "</table>";

?>