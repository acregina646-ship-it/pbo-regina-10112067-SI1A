<?php
// Latihan 10.1: Membuat Class TagihanListrik dan Repository
function formatRupiah($angka) {
    return "Rp " . number_format($angka, 0, ',', '.');
}
// Class Repository untuk menyimpan data tagihan listrik
class TagihanListrikRepository {
    private $data = [
        ["nama" => "Budi", "KWH" => 1200],
        ["nama" => "Sinta", "KWH" => 800],
        ["nama" => "Rani", "KWH" => 1500]
    ];
// Method untuk mendapatkan semua data
    public function getAll() {
        return $this->data;
    }
}
// Class TagihanListrik untuk menghitung total tagihan listrik
class TagihanListrik {
    private $nama;
    private $KWH;
    private $tarif = 1500;
// Method untuk mengisi data nama dan KWH
    public function setData($nama, $KWH) {
        $this->nama = $nama;
        $this->KWH = $KWH;
    }
// Method untuk mendapatkan nama
    public function getNama() {
        return $this->nama;
    }
// Method untuk mendapatkan KWH
    public function getKWH() {
        return $this->KWH;
    }
// Method untuk menghitung total tagihan
    public function hitungTotal() {
        $total = $this->KWH * $this->tarif;
// Diskon jika pemakaian lebih dari 1000 kWh
        if ($this->KWH > 1000) {
            $total -= 50000;
        }
// Mengembalikan total tagihan
        return $total;
    }
}
// Pemakaian class dan repository
$repo = new TagihanListrikRepository();
$data = $repo->getAll();
// Array untuk menyimpan hasil perhitungan
$hasil = [];
foreach ($data as $d) {
    $obj = new TagihanListrik();
    $obj->setData($d["nama"], $d["KWH"]);
// Simpan hasil perhitungan dalam array
    $hasil[] = [
        "nama" => $obj->getNama(),
        "KWH" => $obj->getKWH(),
        "total" => $obj->hitungTotal()
    ];
}

// Output tabel HTML untuk menampilkan data tagihan listrik
echo "<h2>DATA TAGIHAN LISTRIK</h2>";
echo "<table border='1' cellpadding='6'>";
echo "<tr>
        <th>No</th>
        <th>Nama</th>
        <th>Pemakaian (KWH)</th>
        <th>Total Bayar</th>
      </tr>";
// Loop untuk menampilkan setiap baris data dalam tabel
$no = 1;
foreach ($hasil as $h) {
    echo "<tr>";
    echo "<td>" . $no++ . "</td>";
    echo "<td>" . $h["nama"] . "</td>";
    echo "<td>" . $h["KWH"] . "</td>";
    echo "<td>" . formatRupiah($h["total"]) . "</td>";
    echo "</tr>";
}
// Menutup tabel HTML
echo "</table>";
?>