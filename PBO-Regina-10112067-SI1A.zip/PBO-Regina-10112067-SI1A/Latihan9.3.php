<?php 
class manusia{ 
    // menentukan property dengan protected 
    protected $nama = "Ardi"; 
    public $kelas = "SI 2"; // Diubah jadi public agar bisa diakses langsung jika diperlukan

    // method protected
    protected function nama(){ 
        return "Nama : ".$this->nama; 
    } 

    public function tampilkan_nama(){ 
        return $this->nama(); 
    } 

    // PERBAIKAN: Ubah protected menjadi public agar bisa diakses dari luar
    public function tampilkan_kelas(){ 
        return "Kelas : ".$this->kelas; 
    } 
} 

// instansiasi class manusia 
$manusia = new manusia(); 

// memanggil method public
echo $manusia->tampilkan_nama()."\n"; 
echo $manusia->tampilkan_kelas(); // Sekarang ini bisa diakses
?>
