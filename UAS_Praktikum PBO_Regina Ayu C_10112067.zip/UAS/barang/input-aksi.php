<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";

$kd_barang = $_POST['kd_barang'];
$kode_jenis = $_POST['kode_jenis'];
$nama_barang = $_POST['nama_barang'];
$stok = $_POST['stok'];
$harga_beli = $_POST['harga_beli'];
$harga_jual = $_POST['harga_jual'];

mysqli_query($koneksi, "INSERT INTO tb_barang VALUES('$kd_barang','$kode_jenis','$nama_barang',$stok,$harga_beli,$harga_jual,'')");

header("location: index.php?pesan=input");
?>