<?php

echo "Siapa nama kamu: ";
$input_name = fopen("php://stdin", "r");
$name = trim(fgets($input_name));

echo "Welcome $name,  apa kabar ?\n";


?>