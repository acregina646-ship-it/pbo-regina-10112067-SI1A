<?php
interface Hewan {
    // Membuat interface: sebuah class definition yang didalam body-nya hanya terdiri dari definisi fungsi tanpa ada implementasi
    public function Makan();
    public function Bergerak();
    public function Beranak();
}

class Burung implements Hewan {
    public function Makan() {
        return "Burung makan biji-bijian\n";
    }

    public function Bergerak() {
        return "Burung bergerak dengan berjalan, terbang dan melompat\n";
    }

    public function Beranak() {
        return "Burung beranak dengan bertelur\n";
    }
}

class Kambing implements Hewan {
    public function Makan() {
        return "Kambing makan rumput\n";
    }

    public function Bergerak() {
        return "Kambing bergerak dengan berjalan dan berlari\n";
    }

    public function Beranak() {
        return "Kambing beranak dengan melahirkan\n";
    }
}

// Membuat objek
$burung = new Burung();
$kambing = new Kambing();

echo "Perilaku Burung:\n";
echo $burung->Makan();
echo $burung->Bergerak();
echo $burung->Beranak();

echo "\n";

echo "Perilaku Kambing:\n";
echo $kambing->Makan();
echo $kambing->Bergerak();
echo $kambing->Beranak();
?>