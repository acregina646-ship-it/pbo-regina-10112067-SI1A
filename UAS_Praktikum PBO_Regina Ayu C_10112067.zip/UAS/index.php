<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: login.php");
    exit();
}
include "koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Home - Aplikasi Inventory Gudang</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    <div class="judul">		
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Sistem Manajemen Stok Barang</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li>
                    <a href="#">Data Master</a>
                    <ul>
                        <li><a href="barang/index.php">Data Barang</a></li>
                        <li><a href="jenis/index.php">Data Jenis Barang</a></li>
                        <li><a href="supplier/index.php">Data Supplier</a></li>
                        <li><a href="customer/index.php">Data Customer</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#">Transaksi</a>
                    <ul>
                        <li><a href="pembelian/index.php">Transaksi Pembelian</a></li>
                        <li><a href="penjualan/index.php">Transaksi Penjualan</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#">Laporan</a>
                    <ul>
                        <li><a href="laporan/stok_barang.php">Laporan Stok Barang</a></li>
                        <li><a href="laporan/penjualan.php">Laporan Penjualan</a></li>
                    </ul>
                </li>
                <li style="float:right;">
                    <a href="logout.php" style="background:#d9534f; color:white;">Logout (<?php echo $_SESSION['username']; ?>)</a>
                </li>
            </ul>
        </div>
    </div>

    <div class="container">

        <?php
        if(isset($_GET['pesan'])){
            $pesan = $_GET['pesan'];
            if($pesan == "input"){
                echo "<div style='background:#d4edda; color:#155724; padding:10px; margin-bottom:10px;'>Data berhasil di input.</div>";
            }
            else if($pesan == "update"){
                echo "<div style='background:#d4edda; color:#155724; padding:10px; margin-bottom:10px;'>Data berhasil di update.</div>";
            }
            else if($pesan == "hapus"){
                echo "<div style='background:#d4edda; color:#155724; padding:10px; margin-bottom:10px;'>Data berhasil di hapus.</div>";
            }
        }
        ?>

        <h3>Selamat Datang, <?php echo $_SESSION['username']; ?></h3>
        <p>Silakan pilih menu di atas untuk mengelola data inventory gudang.</p>

    </div>

</body>
</html>