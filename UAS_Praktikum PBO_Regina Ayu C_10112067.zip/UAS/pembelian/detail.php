<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";

$no_pembelian = $_GET['id'];
$pembelian = mysqli_fetch_array(mysqli_query($koneksi, "SELECT p.*, s.nama_supplier FROM tb_pembelian p LEFT JOIN tb_supplier s ON p.id_supplier = s.id_supplier WHERE p.no_pembelian='$no_pembelian'"));
?>
<!DOCTYPE html>
<html>
<head>
    <title>Detail Pembelian</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
    <div class="judul">		
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Detail Pembelian</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Pembelian</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <a href="index.php">← Kembali</a>
        
        <h3>Detail Pembelian: <?php echo $no_pembelian; ?></h3>
        
        <table border="0" width="100%">
            <tr><td width="150">Tanggal</td><td>: <?php echo $pembelian['tanggal_pembelian']; ?></td></tr>
            <tr><td>Supplier</td><td>: <?php echo $pembelian['nama_supplier']; ?></td></tr>
            <tr><td>Total Barang</td><td>: <?php echo $pembelian['total_barangall']; ?> pcs</td></tr>
            <tr><td>Total Harga</td><td>: Rp <?php echo number_format($pembelian['total_hargaall'],0,',','.'); ?></td></tr>
        </table>
        
        <br>
        <h4>Daftar Barang</h4>
        
        <table border="1" class="table" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Barang</th>
                    <th>Nama Barang</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = mysqli_query($koneksi, "SELECT d.*, b.nama_barang FROM detail_pembelian d LEFT JOIN tb_barang b ON d.kd_barang = b.kd_barang WHERE d.no_pembelian='$no_pembelian'");
                $nomor = 1;
                while($data = mysqli_fetch_array($query)){
                ?>
                <tr>
                    <td><?php echo $nomor++; ?></td>
                    <td><?php echo $data['kd_barang']; ?></td>
                    <td><?php echo $data['nama_barang']; ?></td>
                    <td><?php echo $data['jumlah_barang']; ?> pcs</td>
                    <td>Rp <?php echo number_format($data['harga_barang'],0,',','.'); ?></td>
                    <td>Rp <?php echo number_format($data['total_harga'],0,',','.'); ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>