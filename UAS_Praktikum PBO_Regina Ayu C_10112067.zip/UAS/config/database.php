<?php
class Database {
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "db_inventory";
    private $connection;

    public function __construct() {
        $this->connect();
    }

    private function connect() {
        try {
            $this->connection = mysqli_connect(
                $this->host, 
                $this->username, 
                $this->password, 
                $this->database
            );
            
            if (!$this->connection) {
                throw new Exception("Koneksi database gagal: " . mysqli_connect_error());
            }
        } catch(Exception $e) {
            die("Error: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->connection;
    }

    public function query($sql) {
        return mysqli_query($this->connection, $sql);
    }

    public function fetchAll($result) {
        $data = [];
        while($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        return $data;
    }

    public function fetchOne($result) {
        return mysqli_fetch_assoc($result);
    }

    public function escape($string) {
        return mysqli_real_escape_string($this->connection, $string);
    }

    public function getLastId() {
        return mysqli_insert_id($this->connection);
    }
}
?>