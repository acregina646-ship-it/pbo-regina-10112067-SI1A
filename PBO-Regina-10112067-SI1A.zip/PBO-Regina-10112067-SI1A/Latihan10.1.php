<?php
function formatRupiah ($angka){
    // Menggunakan '.' sebagai pemisah ribuan agar sesuai standar Indonesia
    return "Rp ". number_format($angka, 0, ',', '.');
}

// SUMBER DATA
class TagihanListrikRepository {
    private $data = [
        ["nama"=> "Budi", "kwh"=>1200],
        ["nama"=> "Sinta", "kwh"=>800], 
        ["nama"=> "Rani", "kwh"=>1500],
    ];

    public function getAll(){
        return $this->data;
    }
}

// Model (Proses Data)
class TagihanListrik {
    private $nama;
    private $kwh;
    private $tarif = 1500; // per kWh

    public function setData($nama, $kwh){
        $this->nama = $nama;
        $this->kwh = $kwh;
    }

    public function getNama(){
        return $this->nama;
    }

    public function hitungTotal(){
        // PERBAIKAN: Gunakan $this->tarif (tanpa tanda $ ekstra setelah panah)
        $total = $this->kwh * $this->tarif;

        // Diskon jika pemakaian besar 
        if ($this->kwh > 1000){
            $total = $total - 50000;
        }
        return $total;
    }
}

// Logika (ALUR PROGRAM)
$repo = new TagihanListrikRepository();
$data = $repo->getAll();

$hasil = [];

foreach ($data as $d){
    $obj = new TagihanListrik();
    $obj->setData($d["nama"], $d["kwh"]);

    $hasil[] = [
        "nama" => $obj->getNama(),
        "kwh"  => $d["kwh"],
        "total" => $obj->hitungTotal()
    ];
}

// VIEW (OUTPUT)
echo "<h2>DATA TAGIHAN LISTRIK</h2>";
echo "<table border='1' cellpadding='6' cellspacing='0'>";
echo "<tr>
        <th>No</th>
        <th>Nama</th>
        <th>Pemakaian (kWh)</th>
        <th>Total Bayar</th>
      </tr>";

$no = 1;
foreach ($hasil as $h){
    echo "<tr>";
    echo "<td>".$no++."</td>";
    echo "<td>".$h["nama"]."</td>";
    // PERBAIKAN: Gunakan "kwh" (huruf kecil) sesuai kunci di array $hasil
    echo "<td>".$h["kwh"]."</td>"; 
    echo "<td>".formatRupiah($h["total"])."</td>";
    echo "</tr>";
} 
// PERBAIKAN: Pindahkan </table> ke luar loop foreach
echo "</table>";
?>