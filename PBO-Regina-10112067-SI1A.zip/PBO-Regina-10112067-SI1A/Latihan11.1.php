<?php

class HtmlElement
{
    // Properti private untuk menyimpan atribut dinamis (seperti id, class, dll)
    private $attributes = [];
    private $tag;

    public function __construct($tag)
    {
        $this->tag = $tag;
    }

    //Magic Method __set() Dipanggil otomatis saat mencoba mengisi nilai ke properti yang tidak ada atau tidak bisa diakses (private).
     
    public function __set($name, $value)
    {
        // Menyimpan nama properti dan nilainya ke dalam array $attributes
        $this->attributes[$name] = $value;
    }

    //Magic Method __get() Dipanggil otomatis saat mencoba mengambil nilai dari properti yang tidak ada.
   
    public function __get($name)
    {
        // Cek apakah key ada di array, jika ada maka kembalikan nilainya
        if (array_key_exists($name, $this->attributes)) {
            return $this->attributes[$name];
        }
    }

    //Method untuk menyusun string HTML lengkap dengan atributnya
    public function html($innerHTML = '')
    {
        // 1. Mulai dengan tag pembuka (misal: <article)
        $html = "<{$this->tag}";

        // 2. Looping array $attributes untuk menambah atribut (misal: id="main")
        foreach ($this->attributes as $key => $value) {
            $html .= ' ' . $key . '="' . $value . '"';
        }

        // 3. Tutup tag pembuka, isi konten, dan tag penutup
        $html .= '>';
        $html .= $innerHTML;
        $html .= "</{$this->tag}>";

        return $html;
    }
}



$article = new HtmlElement('article');

// Karena properti 'id' dan 'class' tidak ada di dalam class,
// maka PHP otomatis menjalankan method __set()
$article->id = 'main';
$article->class = 'light';

// Menampilkan nilai atribut menggunakan __get()
echo $article->class . "<br />"; // Output: light
echo $article->id;              // Output: main

?>
