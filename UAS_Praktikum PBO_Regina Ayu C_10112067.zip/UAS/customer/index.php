<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Customer</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
    <div class="judul">		
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Data Customer</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Data Customer</a></li>
             
            </ul>
        </div>
    </div>

    <div class="container">
        <?php
        if(isset($_GET['pesan'])){
            if($_GET['pesan'] == "input") echo "<div style='background:#d4edda; color:#155724; padding:10px; margin-bottom:10px;'>Data berhasil di input.</div>";
            if($_GET['pesan'] == "update") echo "<div style='background:#d4edda; color:#155724; padding:10px; margin-bottom:10px;'>Data berhasil di update.</div>";
            if($_GET['pesan'] == "hapus") echo "<div style='background:#d4edda; color:#155724; padding:10px; margin-bottom:10px;'>Data berhasil di hapus.</div>";
        }
        ?>
        
        <a class="tombol" href="input.php">+ Tambah Customer Baru</a>
        
        <h3>Data Customer</h3>
        
        <table border="1" class="table">
            <tr>
                <th>No</th>
                <th>ID Customer</th>
                <th>Nama Customer</th>
                <th>Jenis Kelamin</th>
                <th>Alamat</th>
                <th>Telepon</th>
                <th>Email</th>
                <th>Opsi</th>
            </tr>
            <?php
            $query = mysqli_query($koneksi, "SELECT * FROM tb_customer");
            $nomor = 1;
            while($data = mysqli_fetch_array($query)){
            ?>
            <tr>
                <td><?php echo $nomor++; ?></td>
                <td><?php echo $data['id_customer']; ?></td>
                <td><?php echo $data['nama_customer']; ?></td>
                <td><?php echo $data['jenis_kelamin']; ?></td>
                <td><?php echo $data['alamat_customer']; ?></td>
                <td><?php echo $data['telepon_customer']; ?></td>
                <td><?php echo $data['email_customer']; ?></td>
                <td>
                    <a class="edit" href="edit.php?id=<?php echo $data['id_customer']; ?>">Edit</a> |
                    <a class="hapus" href="hapus.php?id=<?php echo $data['id_customer']; ?>" onclick="return confirm('Yakin hapus?')">Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>