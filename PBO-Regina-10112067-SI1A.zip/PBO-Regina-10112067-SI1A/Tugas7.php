<?php

// KELAS UTAMA / INDUK (Berisi data dasar yang dimiliki semua jenis karyawan)
class Employee {
    // data-data dasar yang pasti dipunyai setiap karyawan
    public $nama;
    public $gaji;
    public $lamaKerja;

    // Fungsi otomatis untuk langsung memasukkan nama, gaji, dan lama kerja saat data dibuat
    function __construct($nama, $gaji, $lamaKerja){
        $this->nama = $nama;
        $this->gaji = $gaji;
        $this->lamaKerja = $lamaKerja;
    }

    // Fungsi dasar untuk mengambil nilai gaji pokok
    function getGaji(){
        return $this->gaji;
    }
}

// KELAS ANAK: PROGRAMMER (Menginduk ke kelas Employee)
class Programmer extends Employee {
    // Menulis ulang fungsi getGaji khusus untuk Programmer (karena hitungan bonusnya beda)
    function getGaji(){
        if($this->lamaKerja < 1){
            return $this->gaji; // Kerja kurang dari 1 tahun, cuma dapat gaji pokok
        } elseif($this->lamaKerja <= 10){
            // Kerja 1-10 tahun, dapat bonus 1% per tahun dari gaji pokok
            return $this->gaji + (0.01 * $this->lamaKerja * $this->gaji);
        } else {
            // Kerja di atas 10 tahun, dapat bonus 2% per tahun dari gaji pokok
            return $this->gaji + (0.02 * $this->lamaKerja * $this->gaji);
        }
    }
}

// KELAS ANAK: DIREKTUR (Menginduk ke kelas Employee)
class Direktur extends Employee {
    // Menulis ulang fungsi getGaji khusus untuk Direktur
    function getGaji(){
        $bonus = 0.5 * $this->lamaKerja * $this->gaji; // Bonusnya 50% dikali masa kerja
        $tunjangan = 0.1 * $this->lamaKerja * $this->gaji; // Tunjangannya 10% dikali masa kerja
        return $this->gaji + $bonus + $tunjangan;
    }
}

// KELAS ANAK: PEGAWAI MINGGUAN (Menginduk ke kelas Employee)
class PegawaiMingguan extends Employee {
    // Karena ini pegawai mingguan toko/sales, dia punya data tambahan khusus barang
    public $hargaBarang;
    public $stok;
    public $terjual;

    // Fungsi pembuat data khusus pegawai mingguan
    function __construct($nama, $gaji, $lamaKerja, $hargaBarang, $stok, $terjual){
        
        parent::__construct($nama, $gaji, $lamaKerja);
        // Lalu masukkan data tambahan khusus miliknya sendiri di bawah ini
        $this->hargaBarang = $hargaBarang;
        $this->stok = $stok;
        $this->terjual = $terjual;
    }

    // Menulis ulang fungsi getGaji berdasarkan performa penjualan barang
    function getGaji(){
        $persen = ($this->terjual / $this->stok) * 100; // Hitung berapa persen barang yang sukses terjual

        if($persen > 70){
            $bonus = 0.10 * $this->hargaBarang * $this->terjual; // Kalau jual di atas 70%, bonusnya gede (10%)
        } else {
            $bonus = 0.03 * $this->hargaBarang * $this->terjual; // Kalau di bawah atau sama dengan 70%, bonusnya cuma 3%
        }

        return $this->gaji + $bonus;
    }
}

// FUNGSI BANTUAN: Biar angka gaji berubah jadi format Rupiah (Ada Rp dan titiknya)
function rupiah($angka){
    return "Rp " . number_format($angka, 0, ',', '.');
}

// KUMPULAN DATA MENTAH KARYAWAN
$data = [
    ["Programmer", "Andi", 5000000, 5],
    ["Direktur", "Budi", 10000000, 12],
    ["PegawaiMingguan", "Citra", 2000000, 1, 50000, 100, 80] // Baris ini datanya lebih panjang karena ada data barang
];

// MEMBUAT KEPALA TABEL DI WEBSITE
echo "<table border='1' cellpadding='10' cellspacing='0'>";
echo "<tr>
<th>No</th>
<th>Nama</th>
<th>Jabatan</th>
<th>Masa Kerja</th>
<th>Gaji Akhir</th>
</tr>";

$no = 1; // Untuk nomor urut di tabel nanti

// PROSES MEMBACA DATA SATU PER SATU DAN DIMASUKKAN KE TABEL
foreach($data as $d){

    // Dicek jabatannya, lalu diubah dari data mentah menjadi "Karyawan Nyata" sesuai kelasnya
    if($d[0] == "Programmer"){
        $obj = new Programmer($d[1], $d[2], $d[3]); // Diproses pakai aturan Programmer
    } elseif($d[0] == "Direktur"){
        $obj = new Direktur($d[1], $d[2], $d[3]); // Diproses pakai aturan Direktur
    } else {
        $obj = new PegawaiMingguan($d[1], $d[2], $d[3], $d[4], $d[5], $d[6]); // Diproses pakai aturan Pegawai Mingguan
    }

    // DISETOR KE BARIS TABEL HTML
    // Bagian '$obj->getGaji()' ini hebatnya program: dia otomatis tahu rumus mana yang dipakai tergantung jabatannya
    echo "<tr>
    <td>".$no++."</td>
    <td>".$obj->nama."</td>
    <td>".$d[0]."</td>
    <td>".$obj->lamaKerja." tahun</td>
    <td>".rupiah($obj->getGaji())."</td>
    </tr>";
}

echo "</table>";

?>