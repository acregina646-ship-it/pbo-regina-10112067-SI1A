<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Input Customer</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
    <div class="judul">
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Input Data Customer</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Data Customer</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <a href="index.php">Kembali</a>
        <h3>Form Input Customer</h3>
        
        <form action="input-aksi.php" method="post">
            <table>
                <tr>
                    <td>ID Customer</td>
                    <td><input type="text" name="id_customer" required></td>
                </tr>
                <tr>
                    <td>Nama Customer</td>
                    <td><input type="text" name="nama_customer" required></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td>
                        <select name="jenis_kelamin" required>
                            <option value="">Pilih</option>
                            <option value="Laki-laki">Laki-laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td><textarea name="alamat_customer" rows="3" style="width:100%"></textarea></td>
                </tr>
                <tr>
                    <td>Telepon</td>
                    <td><input type="text" name="telepon_customer"></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><input type="email" name="email_customer"></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="password" name="pass_customer"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Simpan"></td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>