<?php
session_start();
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("location: ../login.php");
    exit();
}
include "../koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Barang</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
    <div class="judul">		
        <h1>Aplikasi Inventory Gudang</h1>
        <h2>Data Barang</h2>
    </div>

    <div class="menu">
        <div class="container">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="index.php">Data Barang</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <?php
        if(isset($_GET['pesan'])){
            if($_GET['pesan'] == "input") echo "<div style='background:#d4edda; color:#155724; padding:10px;'>Data berhasil di input.</div><br>";
            if($_GET['pesan'] == "update") echo "<div style='background:#d4edda; color:#155724; padding:10px;'>Data berhasil di update.</div><br>";
            if($_GET['pesan'] == "hapus") echo "<div style='background:#d4edda; color:#155724; padding:10px;'>Data berhasil di hapus.</div><br>";
        }
        ?>
        
        <a class="tombol" href="input.php">+ Tambah Data Baru</a>
        
        <h3>Data Barang</h3>
        
        <table border="1" class="table">
            <tr>
                <th>No</th>
                <th>Kode Barang</th>
                <th>Nama Barang</th>
                <th>Jenis</th>
                <th>Stok</th>
                <th>Harga Beli</th>
                <th>Harga Jual</th>
                <th>Opsi</th>
            </tr>
            <?php
            $query = mysqli_query($koneksi, "SELECT b.*, j.jenis FROM tb_barang b LEFT JOIN tb_jenis j ON b.kode_jenis = j.kode_jenis");
            $nomor = 1;
            while($data = mysqli_fetch_array($query)){
            ?>
            <tr>
                <td><?php echo $nomor++; ?></td>
                <td><?php echo $data['kd_barang']; ?></td>
                <td><?php echo $data['nama_barang']; ?></td>
                <td><?php echo $data['jenis']; ?></td>
                <td><?php echo $data['stok']; ?></td>
                <td>Rp <?php echo number_format($data['harga_beli'],0,',','.'); ?></td>
                <td>Rp <?php echo number_format($data['harga_jual'],0,',','.'); ?></td>
                <td>
                    <a class="edit" href="edit.php?id=<?php echo $data['kd_barang']; ?>">Edit</a> |
                    <a class="hapus" href="hapus.php?id=<?php echo $data['kd_barang']; ?>" onclick="return confirm('Yakin hapus?')">Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>